# Landing Project

# Auther and Technology
### Seif Eldin Mahmoud
### HTML V5
### CSS V3
### ES V6

# Table of contents
- [Project Title](#project-title)
- [Auther and Technology](#Auther-and-Technology)
- [Table of contents](#table-of-contents)
- [Installation](#installation)
- [Development](#development)
- [License](#license)
- [Footer](#footer)

# Installation
[(Back to top)](#table-of-contents)

After downloading the zip file open any browser you have on your windows or Mac and by using ctrl + o for Win or command + o for Mac look for the index.html file and open it to open the  web page.

# Development
[(Back to top)](#table-of-contents)

you can modify the code by a lot of way either by change the DOM using the HTMl file "index" using the any notepad or texteditor and the HTML V5 or by change the page styles either by addimg your own CSS file to the folder contain CSS stylesheets "CSS folder" and use the link element to link it to the HTML file ("notes: add your own css file link element after the main css link element to avoid overwrite your css file") or sampily by edit the main CSS stylingsheet itself, the same as the JavaScript file but this time you will use the script element insted of the link.

The project html file is made of 4 sections in the main element and the job for the javaScript file is to build up the navegation bar dynamicly as if there is 5th section it will add it automaticly to the navbar insted os add it manualy to the ul list that all happen throught the function "buildNav()".

The project 2nd task is to transmits between the section throught the navbar using click event and ScrollIntoView() function with smooth transition not vertial jump as anchor elements do.

and the last task is to check wheather the element is in view port or not which is happen using function "isInViewPort()" that returns boolean with the asnwer either true or false and depending on this answer we will add the class active to the section or not using the appendChild() method. 

# License
[(Back to top)](#table-of-contents)

[GNU General Public License version 3](https://opensource.org/licenses/GPL-3.0)

# Footer
[(Back to top)](#table-of-contents)
The End of the file all the JavaScript code right in app.js go to Seif Eldin Mahmoud.